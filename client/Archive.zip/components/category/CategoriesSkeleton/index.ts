export { default } from './CategoriesSkeleton';
