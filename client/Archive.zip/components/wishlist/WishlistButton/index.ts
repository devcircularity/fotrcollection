export { default } from './WishlistButton';
